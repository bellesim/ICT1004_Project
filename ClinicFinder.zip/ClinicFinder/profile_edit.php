<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="css/main.css">
        <title>Home</title>
        <?php include "nav.inc.php"; ?>

    </head>
    
    <header>
        
    </header>
    
    <body>

        <div class="container">
            <p>Enter your contents here for Profile Edit! :) </p>
        </div>            
            
        
        
<?php include "footer.inc.php";  ?>

    </body>
</html>
