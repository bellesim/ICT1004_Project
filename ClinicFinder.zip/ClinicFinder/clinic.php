<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="css/main.css">

        <title>Clinic</title>
    </head>
 <?php include "nav.inc.php"; ?>

    <body>
        <?php
        // put your code here
        ?>
    </body>
    
<?php include "footer.inc.php";  ?>
    
</html>
