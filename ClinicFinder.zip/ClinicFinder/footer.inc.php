<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            -
        </style>
    </head>
    <body>
    </body>


    <footer>
               <!--<a href="index.php"><img id="logo" src="images/logo.PNG" alt="Logo"/></a> -->
        <div class="container">
            <p class="split-para">

                <span style="float:right;">Copyright &copy; 2020 Clinic Finder. All rights reserved.</span>
                <span style="float:left;">Terms & Conditions &nbsp; | &nbsp; Privacy Policy &nbsp; | &nbsp; Accessibility &nbsp; | &nbsp; Legal &nbsp; |</span>

            </p> 
        </div>
    </footer>
</html>


